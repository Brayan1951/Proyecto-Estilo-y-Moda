import { useState } from "react";


function useForm(initState) {
    
const [formData, setFormData] = useState(initState)


}