import React from 'react'

export  function NotFoundPage() {
  return (
    <div>NotFound</div>
  )
}
