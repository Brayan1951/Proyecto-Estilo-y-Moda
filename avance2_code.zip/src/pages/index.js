
export {InicioPage} from "./Inicio/InicioPage";
export {NosotrosPage} from "./Nosotros/NosotrosPage";
export { TiendaPage } from "./Tienda/TiendaPage";
export { SedesPage } from "./Sedes/SedesPage";
export { ContactoPage } from "./Contacto/ContactoPage";


export {NotFoundPage} from "./NotFound/NotFoundPage";
