import React from 'react'
import Sedes from './Sedes';

export  function SedesPage() {
  return (
    <div className='container'> 
    <Sedes/> 
    </div>
  );
}
